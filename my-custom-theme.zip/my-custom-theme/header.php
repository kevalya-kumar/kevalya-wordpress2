<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
</head>
<body>
<header>
    <h2><?php bloginfo('name'); ?></h2>
    <nav><a href="/">Home</a></nav>
</header>